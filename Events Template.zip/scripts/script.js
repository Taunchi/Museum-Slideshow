let items = [];

getData();


async function getData() {
  const response = await fetch('http://nmdcamediadev.wpengine.com/wp-json/tribe/events/v1/events');
  const data = await response.json();
  events = data.events;

  console.log(response);
  console.log(events);
  
  events = Array.from(events);
  console.log(events);
  for(i = 0; i < events.length; i++) {
    console.log(events[i])
  }
  //try to get description string
  console.log(events[0].description)
  console.log(events[0].image.url)
  console.log(events[0].venue)

}

function showItem(index) {

}
